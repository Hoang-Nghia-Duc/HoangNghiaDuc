﻿using CafeManagementApplication.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementApplication
{
    public partial class fBillBuy : Form
    {
        public fBillBuy()
        {
            InitializeComponent();
        }
        double sumMoney;
        double pay;
        private void fBillBuy_Load(object sender, EventArgs e)
        {
            // hóa đơn chi tiết
            lv_product.Columns[0].Width = (int)(lv_product.Width * 0.25);
            lv_product.Columns[1].Width = (int)(lv_product.Width * 0.14);
            lv_product.Columns[2].Width = (int)(lv_product.Width * 0.14);
            lv_product.Columns[3].Width = (int)(lv_product.Width * 0.14);
            lv_product.Columns[4].Width = (int)(lv_product.Width * 0.14);
            lv_product.Columns[5].Width = (int)(lv_product.Width * 0.14);
            lv_product.Columns[6].Width = (int)(lv_product.Width * 0.2);
            




            lv_product.View = View.Details;
            lv_product.GridLines = true;
            lv_product.FullRowSelect = true;

            //hóa đơn
            lv_bill.Columns[0].Width = (int)(lv_product.Width * 0.25);
            lv_bill.Columns[1].Width = (int)(lv_product.Width * 0.25);
            lv_bill.Columns[2].Width = (int)(lv_product.Width * 0.25);
            lv_bill.Columns[3].Width = (int)(lv_product.Width * 0.25);
            lv_bill.Columns[4].Width = (int)(lv_product.Width * 0.35);


            lv_bill.View = View.Details;
            lv_bill.GridLines = true;
            lv_bill.FullRowSelect = true;
            load();

        }

        private void load()
        {
            string query = "select * from NGUYENLIEU";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_sp.DataSource = table;
            ds_sp.DisplayMember = "TenNL";
            ds_sp.ValueMember = "MaNL";
            //nv
            string query2 = "select * from NHANVIEN";
            DataTable table2 = DataProvider.Instance.ExecuteQuery(query2);
            ds_nv.DataSource = table2;
            ds_nv.DisplayMember = "TenNV";
            ds_nv.ValueMember = "MaNV";
            //ncc
            string query3 = "select * from NHACUNGCAP";
            DataTable table3 = DataProvider.Instance.ExecuteQuery(query3);
            ds_ncc.DataSource = table3;
            ds_ncc.DisplayMember = "TenNCC";
            ds_ncc.ValueMember = "MaNCC";
        }
        private void loadBill()
        {
            sumMoney = 0.0;
            pay = 0.0;
            foreach (ListViewItem item in lv_product.Items)
            {
                sumMoney += Convert.ToInt32(item.SubItems[4].Text);

            }
            double giamgia = (Convert.ToInt32(nud_discount.Text));

            pay = sumMoney - sumMoney * (giamgia / 100);
            lv_bill.Items.Clear();
            if (ds_ncc.Text == null)
            {
                ListViewItem bill = lv_bill.Items.Add("nobody");
                bill.SubItems.Add(sumMoney.ToString());
                bill.SubItems.Add(nud_discount.Text);
                bill.SubItems.Add(pay.ToString());
                bill.SubItems.Add(ds_nv.Text);
            }
            else
            {
                ListViewItem bill = lv_bill.Items.Add(ds_ncc.Text);
                bill.SubItems.Add(sumMoney.ToString());
                bill.SubItems.Add(nud_discount.Text);
                bill.SubItems.Add(pay.ToString());
                bill.SubItems.Add(ds_nv.Text);


            }
        }

        private void reset()
        {
            lv_product.Items.Clear();
            lv_bill.Items.Clear();
            txt_phone.Text = string.Empty;
            ds_ncc.Text = string.Empty;
            txt_search.Text = string.Empty;
            ds_sp.Text = string.Empty;
            txt_DVT.Text = string.Empty;
            txt_price.Text = string.Empty;
            nud_number.Text = "0";
            nud_discount.Text = "0";
            loadBill();
        }

        private void lv_product_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lv_product.SelectedItems.Count > 0)
            {
                ds_sp.Text = lv_product.SelectedItems[0].SubItems[0].Text;
                nud_number.Text = lv_product.SelectedItems[0].SubItems[1].Text;
                txt_DVT.Text = lv_product.SelectedItems[0].SubItems[2].Text;
                txt_price.Text = lv_product.SelectedItems[0].SubItems[3].Text;
                nud_ck.Text = lv_product.SelectedItems[0].SubItems[5].Text;



            }
        }

        private void btn_searchNCC_Click(object sender, EventArgs e)
        {
            string search = txt_phone.Text;
            string query = "select * from NhaCungCap where SDT like '%" + search + "%' or TenNCC like N'%"+ search + "%'";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_ncc.DataSource = table;
            ds_ncc.DisplayMember = "TenNCC";
            ds_ncc.ValueMember = "SDT";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (ds_sp.Text == "")
            {
                MessageBox.Show("Phải chọn  1 sản phẩm");
                return;
            }

            int sum,tt;
            foreach (ListViewItem i in lv_product.Items)
            {
                if (i.SubItems[0].Text == ds_sp.Text)
                {
                    int count = Convert.ToInt32(i.SubItems[1].Text);
                    count += Convert.ToInt32(nud_number.Text);
                    i.SubItems[1].Text = count.ToString();
                    sum = count * Convert.ToInt32(i.SubItems[3].Text);
                    tt = sum - Convert.ToInt32((nud_ck.Text));

                    i.SubItems[2].Text = txt_DVT.Text;
                    i.SubItems[3].Text = txt_price.Text;
                    i.SubItems[4].Text = sum.ToString();
                    i.SubItems[5].Text=(nud_ck.Text);
                    i.SubItems[6].Text=(tt.ToString());
                    loadBill();
                    return;
                }
            }
            sum = Convert.ToInt32((txt_price.Text)) * Convert.ToInt32(nud_number.Text);
            ListViewItem item = lv_product.Items.Add(ds_sp.Text);
            item.SubItems.Add(nud_number.Text);
            item.SubItems.Add(txt_DVT.Text);
            item.SubItems.Add(txt_price.Text);
            item.SubItems.Add(sum.ToString());
            item.SubItems.Add(nud_ck.Text);
            tt = sum - Convert.ToInt32((nud_ck.Text));
            item.SubItems.Add(tt.ToString());



            loadBill();
        }

        private void ds_ncc_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadBill();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string query = "select * from NGUYENLIEU where TenNL like N'%"+ txt_search.Text + "%'";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_sp.DataSource = table;
            ds_sp.DisplayMember = "TenNL";
            ds_sp.ValueMember = "MaNL";
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (lv_product.SelectedItems.Count > 0)
            {
                lv_product.SelectedItems[0].SubItems[0].Text = (ds_sp.Text);
                lv_product.SelectedItems[0].SubItems[1].Text = nud_number.Text;
                lv_product.SelectedItems[0].SubItems[2].Text = txt_DVT.Text;
                lv_product.SelectedItems[0].SubItems[3].Text = txt_price.Text;
                int sum = Convert.ToInt32(nud_number.Text) * Convert.ToInt32(txt_price.Text);
                lv_product.SelectedItems[0].SubItems[4].Text = sum.ToString();
                lv_product.SelectedItems[0].SubItems[5].Text = nud_ck.Text;
                int tt = sum - Convert.ToInt32((nud_ck.Text));
                lv_product.SelectedItems[0].SubItems[6].Text = tt.ToString();



            }
            else
            {
                MessageBox.Show("Phải chọn  1 dòng");
            }
            loadBill();
        }

        private void nud_discount_ValueChanged(object sender, EventArgs e)
        {
            loadBill();
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (lv_product.SelectedItems.Count > 0)
            {
                lv_product.Items.Remove(lv_product.SelectedItems[0]);
            }
            else
            {
                MessageBox.Show("Phải chọn  1 dòng");
            }
            loadBill();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void btn_bill_Click(object sender, EventArgs e)
        {
            /*
            string chietkhau = nud_discount.Text;
            string sdt = ds_ncc.SelectedValue.ToString();
            string manv = ds_nv.SelectedValue.ToString();



            string query = "exec sp_addBillnh " + chietkhau + ",'" + sdt + "', '"+manv+"'";
            DataProvider.Instance.ExecuteQuery(query);
            //Hóa đơn chi tiết
            string tenNL, Soluong, donvi, dongia,giamgia,thanhtien;
            foreach (ListViewItem item in lv_product.Items)
            {
                tenNL = item.SubItems[0].Text;
                Soluong = item.SubItems[1].Text;
                donvi = item.SubItems[2].Text;
                dongia = item.SubItems[3].Text;
                giamgia = item.SubItems[5].Text;
                thanhtien = item.SubItems[6].Text;

                query = "exec sp_addBillnh_info N'"+ tenNL + "',"+ Soluong + ",N'"+ donvi + "', "+dongia+","+ giamgia + ","+thanhtien+"";
                DataProvider.Instance.ExecuteQuery(query);
            }
            reset();
            MessageBox.Show("Nhập hàng thành công");
            */
            try
            {
                string chietkhau = nud_discount.Text;
                string sdt = ds_ncc.SelectedValue.ToString();
                string manv = ds_nv.SelectedValue.ToString();



                string query = "exec sp_addBillnh " + chietkhau + ",'" + sdt + "', '" + manv + "'";
                DataProvider.Instance.ExecuteQuery(query);
                //Hóa đơn chi tiết
                string tenNL, Soluong, donvi, dongia, giamgia, thanhtien;
                foreach (ListViewItem item in lv_product.Items)
                {
                    tenNL = item.SubItems[0].Text;
                    Soluong = item.SubItems[1].Text;
                    donvi = item.SubItems[2].Text;
                    dongia = item.SubItems[3].Text;
                    giamgia = item.SubItems[5].Text;
                    thanhtien = item.SubItems[6].Text;

                    query = "exec sp_addBillnh_info N'" + tenNL + "'," + Soluong + ",N'" + donvi + "', " + dongia + "," + giamgia + "," + thanhtien + "";
                    DataProvider.Instance.ExecuteQuery(query);
                }
                reset();
                MessageBox.Show("Nhập hàng thành công");
            }
            catch (SqlException ex)
            {
                reset();
                MessageBox.Show("Có lỗi");
            }

        }

        private void ds_nv_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadBill();
        }
    }
}
