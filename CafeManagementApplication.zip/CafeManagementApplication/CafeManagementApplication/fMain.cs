﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementApplication
{
    public partial class fMain : Form
    {
        public fMain()
        {
            InitializeComponent();
        }

        private void fMain_Load(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            TopMost = false;
        }

        private void btn_power_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //from con
        private Form CurrentFormChild;
        private void OpenChildForm(Form ChildForm)
        {
            if (CurrentFormChild != null)
            {
                CurrentFormChild.Close();
            }
            CurrentFormChild = ChildForm;
            ChildForm.TopLevel = false;
            ChildForm.FormBorderStyle = FormBorderStyle.None;
            ChildForm.Dock = DockStyle.Fill;
            pn_body.Controls.Add(ChildForm);
            pn_body.Tag = ChildForm;
            ChildForm.BringToFront();
            ChildForm.Show();
        }

        private void btn_sale_Click(object sender, EventArgs e)
        {
            OpenChildForm(new fBill());
        }

        private void btn_menu_Click(object sender, EventArgs e)
        {
            OpenChildForm(new fMenu());
        }

        private void btn_supplier_Click(object sender, EventArgs e)
        {
            OpenChildForm(new fSupplier());
        }

        private void btn_client_Click(object sender, EventArgs e)
        {
            OpenChildForm(new fClient());

        }

        private void btn_staff_Click(object sender, EventArgs e)
        {
            OpenChildForm(new fStaff());

        }

        private void btn_buy_Click(object sender, EventArgs e)
        {
            OpenChildForm(new fBillBuy());

        }

        private void btn_statistical_Click(object sender, EventArgs e)
        {
            OpenChildForm(new fStatistical());

        }
    }
}
