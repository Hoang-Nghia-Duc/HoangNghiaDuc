﻿namespace CafeManagementApplication
{
    partial class fBillBuy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel6 = new System.Windows.Forms.Panel();
            this.lv_bill = new System.Windows.Forms.ListView();
            this.ncc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TongTien = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tonggiamgia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ThanhToan = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_bill = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.nud_discount = new System.Windows.Forms.NumericUpDown();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.nud_number = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.ds_sp = new System.Windows.Forms.ComboBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_searchNCC = new System.Windows.Forms.Button();
            this.ds_ncc = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lv_product = new System.Windows.Forms.ListView();
            this.TenSP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.soluong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.donvi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dongia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tongtienn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label6 = new System.Windows.Forms.Label();
            this.txt_DVT = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_price = new System.Windows.Forms.NumericUpDown();
            this.thanhtien = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.giamgia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label8 = new System.Windows.Forms.Label();
            this.nud_ck = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.ds_nv = new System.Windows.Forms.ComboBox();
            this.nv = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_discount)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_number)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_price)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ck)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.lv_bill);
            this.panel6.Location = new System.Drawing.Point(641, 560);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(706, 141);
            this.panel6.TabIndex = 6;
            // 
            // lv_bill
            // 
            this.lv_bill.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lv_bill.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ncc,
            this.TongTien,
            this.tonggiamgia,
            this.ThanhToan,
            this.nv});
            this.lv_bill.HideSelection = false;
            this.lv_bill.Location = new System.Drawing.Point(4, 4);
            this.lv_bill.Name = "lv_bill";
            this.lv_bill.Size = new System.Drawing.Size(699, 134);
            this.lv_bill.TabIndex = 0;
            this.lv_bill.UseCompatibleStateImageBehavior = false;
            this.lv_bill.View = System.Windows.Forms.View.Details;
            // 
            // ncc
            // 
            this.ncc.Text = "Nhà cung cấp";
            // 
            // TongTien
            // 
            this.TongTien.Text = "Tổng tiền";
            // 
            // tonggiamgia
            // 
            this.tonggiamgia.Text = "Tổng giảm giá";
            // 
            // ThanhToan
            // 
            this.ThanhToan.Text = "Tổng thanh toán";
            this.ThanhToan.Width = 289;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(41, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(594, 687);
            this.panel1.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.ds_nv);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.btn_bill);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.nud_discount);
            this.panel5.Location = new System.Drawing.Point(17, 562);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(557, 122);
            this.panel5.TabIndex = 2;
            // 
            // btn_bill
            // 
            this.btn_bill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_bill.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bill.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_bill.Location = new System.Drawing.Point(350, 40);
            this.btn_bill.Name = "btn_bill";
            this.btn_bill.Size = new System.Drawing.Size(129, 49);
            this.btn_bill.TabIndex = 13;
            this.btn_bill.Text = "Nhập hàng";
            this.btn_bill.UseVisualStyleBackColor = false;
            this.btn_bill.Click += new System.EventHandler(this.btn_bill_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(4, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 19);
            this.label5.TabIndex = 13;
            this.label5.Text = "Giảm giá (VNĐ) :";
            // 
            // nud_discount
            // 
            this.nud_discount.Location = new System.Drawing.Point(165, 67);
            this.nud_discount.Name = "nud_discount";
            this.nud_discount.Size = new System.Drawing.Size(123, 22);
            this.nud_discount.TabIndex = 0;
            this.nud_discount.ValueChanged += new System.EventHandler(this.nud_discount_ValueChanged);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.nud_ck);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.txt_price);
            this.panel4.Controls.Add(this.txt_DVT);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.btn_reset);
            this.panel4.Controls.Add(this.btn_search);
            this.panel4.Controls.Add(this.btn_remove);
            this.panel4.Controls.Add(this.btn_update);
            this.panel4.Controls.Add(this.btn_add);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.nud_number);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.ds_sp);
            this.panel4.Controls.Add(this.txt_search);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(17, 151);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(557, 405);
            this.panel4.TabIndex = 1;
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_reset.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_reset.Location = new System.Drawing.Point(393, 335);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(86, 49);
            this.btn_reset.TabIndex = 12;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_search.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_search.Location = new System.Drawing.Point(378, 32);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(86, 34);
            this.btn_search.TabIndex = 11;
            this.btn_search.Text = "Tìm";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_remove
            // 
            this.btn_remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_remove.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_remove.Location = new System.Drawing.Point(301, 335);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(86, 49);
            this.btn_remove.TabIndex = 10;
            this.btn_remove.Text = "Xóa";
            this.btn_remove.UseVisualStyleBackColor = false;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_update.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_update.Location = new System.Drawing.Point(209, 335);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(86, 49);
            this.btn_update.TabIndex = 9;
            this.btn_update.Text = "Sửa";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_add.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_add.Location = new System.Drawing.Point(117, 335);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(86, 49);
            this.btn_add.TabIndex = 8;
            this.btn_add.Text = "Thêm";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(4, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "Số lượng";
            // 
            // nud_number
            // 
            this.nud_number.Location = new System.Drawing.Point(165, 128);
            this.nud_number.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.nud_number.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_number.Name = "nud_number";
            this.nud_number.Size = new System.Drawing.Size(192, 22);
            this.nud_number.TabIndex = 6;
            this.nud_number.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tên nguyên liệu";
            // 
            // ds_sp
            // 
            this.ds_sp.FormattingEnabled = true;
            this.ds_sp.Location = new System.Drawing.Point(165, 82);
            this.ds_sp.Name = "ds_sp";
            this.ds_sp.Size = new System.Drawing.Size(192, 24);
            this.ds_sp.TabIndex = 4;
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(165, 37);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(192, 22);
            this.txt_search.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tìm nguyên liệu";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btn_searchNCC);
            this.panel3.Controls.Add(this.ds_ncc);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.txt_phone);
            this.panel3.Location = new System.Drawing.Point(17, 27);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(557, 118);
            this.panel3.TabIndex = 0;
            // 
            // btn_searchNCC
            // 
            this.btn_searchNCC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_searchNCC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_searchNCC.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_searchNCC.Location = new System.Drawing.Point(378, 20);
            this.btn_searchNCC.Name = "btn_searchNCC";
            this.btn_searchNCC.Size = new System.Drawing.Size(86, 34);
            this.btn_searchNCC.TabIndex = 13;
            this.btn_searchNCC.Text = "Tìm";
            this.btn_searchNCC.UseVisualStyleBackColor = false;
            this.btn_searchNCC.Click += new System.EventHandler(this.btn_searchNCC_Click);
            // 
            // ds_ncc
            // 
            this.ds_ncc.FormattingEnabled = true;
            this.ds_ncc.Location = new System.Drawing.Point(117, 66);
            this.ds_ncc.Name = "ds_ncc";
            this.ds_ncc.Size = new System.Drawing.Size(192, 24);
            this.ds_ncc.TabIndex = 2;
            this.ds_ncc.SelectedIndexChanged += new System.EventHandler(this.ds_ncc_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "SĐT NCC";
            // 
            // txt_phone
            // 
            this.txt_phone.Location = new System.Drawing.Point(117, 27);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(192, 22);
            this.txt_phone.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.lv_product);
            this.panel2.Location = new System.Drawing.Point(641, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(709, 538);
            this.panel2.TabIndex = 4;
            // 
            // lv_product
            // 
            this.lv_product.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lv_product.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TenSP,
            this.soluong,
            this.donvi,
            this.dongia,
            this.tongtienn,
            this.giamgia,
            this.thanhtien});
            this.lv_product.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lv_product.HideSelection = false;
            this.lv_product.Location = new System.Drawing.Point(3, 4);
            this.lv_product.Name = "lv_product";
            this.lv_product.Size = new System.Drawing.Size(703, 531);
            this.lv_product.TabIndex = 0;
            this.lv_product.UseCompatibleStateImageBehavior = false;
            this.lv_product.View = System.Windows.Forms.View.Details;
            this.lv_product.SelectedIndexChanged += new System.EventHandler(this.lv_product_SelectedIndexChanged);
            // 
            // TenSP
            // 
            this.TenSP.Text = "Tên nguyên liệu";
            this.TenSP.Width = 194;
            // 
            // soluong
            // 
            this.soluong.Text = "Số lượng";
            this.soluong.Width = 145;
            // 
            // donvi
            // 
            this.donvi.Text = "Đơn vị";
            this.donvi.Width = 141;
            // 
            // dongia
            // 
            this.dongia.Text = "Đơn giá";
            // 
            // tongtienn
            // 
            this.tongtienn.Text = "Tổng tiền";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 19);
            this.label6.TabIndex = 14;
            this.label6.Text = "Đơn vị";
            // 
            // txt_DVT
            // 
            this.txt_DVT.Location = new System.Drawing.Point(165, 174);
            this.txt_DVT.Name = "txt_DVT";
            this.txt_DVT.Size = new System.Drawing.Size(192, 22);
            this.txt_DVT.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 19);
            this.label7.TabIndex = 17;
            this.label7.Text = "Đơn giá";
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(165, 216);
            this.txt_price.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.txt_price.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(192, 22);
            this.txt_price.TabIndex = 16;
            this.txt_price.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // thanhtien
            // 
            this.thanhtien.Text = "Thành tiền";
            // 
            // giamgia
            // 
            this.giamgia.Text = "Giảm giá";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 261);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 19);
            this.label8.TabIndex = 19;
            this.label8.Text = "Giảm giá (VNĐ)";
            // 
            // nud_ck
            // 
            this.nud_ck.Location = new System.Drawing.Point(165, 258);
            this.nud_ck.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.nud_ck.Name = "nud_ck";
            this.nud_ck.Size = new System.Drawing.Size(192, 22);
            this.nud_ck.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 19);
            this.label9.TabIndex = 14;
            this.label9.Text = "Người thực hiện";
            // 
            // ds_nv
            // 
            this.ds_nv.FormattingEnabled = true;
            this.ds_nv.Location = new System.Drawing.Point(165, 30);
            this.ds_nv.Name = "ds_nv";
            this.ds_nv.Size = new System.Drawing.Size(121, 24);
            this.ds_nv.TabIndex = 15;
            this.ds_nv.SelectedIndexChanged += new System.EventHandler(this.ds_nv_SelectedIndexChanged);
            // 
            // nv
            // 
            this.nv.Text = "Người thực hiện";
            // 
            // fBillBuy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(226)))), ((int)(((byte)(207)))));
            this.ClientSize = new System.Drawing.Size(1391, 715);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "fBillBuy";
            this.Text = "fBillBuy";
            this.Load += new System.EventHandler(this.fBillBuy_Load);
            this.panel6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_discount)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_number)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_price)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ck)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ListView lv_bill;
        private System.Windows.Forms.ColumnHeader ncc;
        private System.Windows.Forms.ColumnHeader TongTien;
        private System.Windows.Forms.ColumnHeader tonggiamgia;
        private System.Windows.Forms.ColumnHeader ThanhToan;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_bill;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nud_discount;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nud_number;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox ds_sp;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_searchNCC;
        private System.Windows.Forms.ComboBox ds_ncc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListView lv_product;
        private System.Windows.Forms.ColumnHeader TenSP;
        private System.Windows.Forms.ColumnHeader soluong;
        private System.Windows.Forms.ColumnHeader donvi;
        private System.Windows.Forms.ColumnHeader dongia;
        private System.Windows.Forms.ColumnHeader tongtienn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_DVT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown txt_price;
        private System.Windows.Forms.ColumnHeader thanhtien;
        private System.Windows.Forms.ColumnHeader giamgia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nud_ck;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox ds_nv;
        private System.Windows.Forms.ColumnHeader nv;
    }
}