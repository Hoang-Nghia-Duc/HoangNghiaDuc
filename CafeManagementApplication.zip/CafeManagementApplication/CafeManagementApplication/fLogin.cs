﻿using CafeManagementApplication.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CafeManagementApplication
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();
        }

        private void fLogin_Load(object sender, EventArgs e)
        {
            /*
            int w=Screen.PrimaryScreen.Bounds.Width;
            int h=Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(w, h);
            this.Size = new Size(w, h);
            */
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            TopMost = false;
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            string userName = txt_user.Text;
            string passWord = txt_pass.Text;
            if (Login(userName, passWord))
            {
                
                fMain f = new fMain();
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("Sai tên tài khoản hoặc mật khẩu!");
            }
        }
        bool Login(string userName, string passWord)
        {
            try
            {
                string query = "exec spLogin N'" + userName + "', N'" + passWord + "'";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                return result.Rows.Count > 0;
            }
            catch (SqlException ex) 
            { 
                return false;
            }
            
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có thật sự muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }
    }
}
