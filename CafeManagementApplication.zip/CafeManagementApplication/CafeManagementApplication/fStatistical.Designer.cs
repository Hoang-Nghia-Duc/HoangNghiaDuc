﻿namespace CafeManagementApplication
{
    partial class fStatistical
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_TK = new System.Windows.Forms.Button();
            this.date_to = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.date_from = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dtgv_hdb = new System.Windows.Forms.DataGridView();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtgv_hdbct = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dtgv_hdn = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dtgv_hdnct = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdbct)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdn)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdnct)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.btn_TK);
            this.panel1.Controls.Add(this.date_to);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.date_from);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1147, 71);
            this.panel1.TabIndex = 0;
            // 
            // btn_TK
            // 
            this.btn_TK.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_TK.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.btn_TK.Location = new System.Drawing.Point(521, 16);
            this.btn_TK.Name = "btn_TK";
            this.btn_TK.Size = new System.Drawing.Size(126, 42);
            this.btn_TK.TabIndex = 4;
            this.btn_TK.Text = "Thống kê";
            this.btn_TK.UseVisualStyleBackColor = true;
            this.btn_TK.Click += new System.EventHandler(this.btn_TK_Click);
            // 
            // date_to
            // 
            this.date_to.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.date_to.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.date_to.Location = new System.Drawing.Point(800, 22);
            this.date_to.Name = "date_to";
            this.date_to.Size = new System.Drawing.Size(200, 27);
            this.date_to.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(696, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Đến ngày";
            // 
            // date_from
            // 
            this.date_from.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.date_from.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.date_from.Location = new System.Drawing.Point(247, 22);
            this.date_from.Name = "date_from";
            this.date_from.Size = new System.Drawing.Size(200, 27);
            this.date_from.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(155, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Từ ngày";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dtgv_hdb);
            this.panel2.Location = new System.Drawing.Point(10, 129);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(772, 286);
            this.panel2.TabIndex = 1;
            // 
            // dtgv_hdb
            // 
            this.dtgv_hdb.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgv_hdb.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgv_hdb.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_hdb.Location = new System.Drawing.Point(3, 4);
            this.dtgv_hdb.Name = "dtgv_hdb";
            this.dtgv_hdb.ReadOnly = true;
            this.dtgv_hdb.RowHeadersWidth = 51;
            this.dtgv_hdb.RowTemplate.Height = 24;
            this.dtgv_hdb.Size = new System.Drawing.Size(766, 279);
            this.dtgv_hdb.TabIndex = 0;
            this.dtgv_hdb.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_hdb_CellClick);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dtgv_hdbct);
            this.panel3.Location = new System.Drawing.Point(788, 129);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(369, 286);
            this.panel3.TabIndex = 2;
            // 
            // dtgv_hdbct
            // 
            this.dtgv_hdbct.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgv_hdbct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgv_hdbct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_hdbct.Location = new System.Drawing.Point(3, 4);
            this.dtgv_hdbct.Name = "dtgv_hdbct";
            this.dtgv_hdbct.ReadOnly = true;
            this.dtgv_hdbct.RowHeadersWidth = 51;
            this.dtgv_hdbct.RowTemplate.Height = 24;
            this.dtgv_hdbct.Size = new System.Drawing.Size(363, 279);
            this.dtgv_hdbct.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dtgv_hdn);
            this.panel4.Location = new System.Drawing.Point(13, 461);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(772, 286);
            this.panel4.TabIndex = 2;
            // 
            // dtgv_hdn
            // 
            this.dtgv_hdn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgv_hdn.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgv_hdn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_hdn.Location = new System.Drawing.Point(3, 4);
            this.dtgv_hdn.Name = "dtgv_hdn";
            this.dtgv_hdn.ReadOnly = true;
            this.dtgv_hdn.RowHeadersWidth = 51;
            this.dtgv_hdn.RowTemplate.Height = 24;
            this.dtgv_hdn.Size = new System.Drawing.Size(766, 279);
            this.dtgv_hdn.TabIndex = 0;
            this.dtgv_hdn.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_hdn_CellClick);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(this.dtgv_hdnct);
            this.panel5.Location = new System.Drawing.Point(788, 461);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(369, 286);
            this.panel5.TabIndex = 3;
            // 
            // dtgv_hdnct
            // 
            this.dtgv_hdnct.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgv_hdnct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgv_hdnct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_hdnct.Location = new System.Drawing.Point(3, 4);
            this.dtgv_hdnct.Name = "dtgv_hdnct";
            this.dtgv_hdnct.ReadOnly = true;
            this.dtgv_hdnct.RowHeadersWidth = 51;
            this.dtgv_hdnct.RowTemplate.Height = 24;
            this.dtgv_hdnct.Size = new System.Drawing.Size(363, 279);
            this.dtgv_hdnct.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Bán hàng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 434);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nhập hàng";
            // 
            // fStatistical
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(226)))), ((int)(((byte)(207)))));
            this.ClientSize = new System.Drawing.Size(1172, 909);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "fStatistical";
            this.Text = "fStatistical";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdbct)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdn)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_hdnct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker date_from;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker date_to;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_TK;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dtgv_hdb;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dtgv_hdbct;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dtgv_hdn;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dtgv_hdnct;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}