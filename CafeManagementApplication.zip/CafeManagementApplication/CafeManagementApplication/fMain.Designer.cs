﻿namespace CafeManagementApplication
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_power = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_sale = new System.Windows.Forms.Button();
            this.btn_menu = new System.Windows.Forms.Button();
            this.btn_buy = new System.Windows.Forms.Button();
            this.btn_supplier = new System.Windows.Forms.Button();
            this.btn_client = new System.Windows.Forms.Button();
            this.btn_staff = new System.Windows.Forms.Button();
            this.btn_statistical = new System.Windows.Forms.Button();
            this.pn_body = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.panel1.Controls.Add(this.btn_power);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1262, 89);
            this.panel1.TabIndex = 0;
            // 
            // btn_power
            // 
            this.btn_power.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_power.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_power.BackgroundImage = global::CafeManagementApplication.Properties.Resources.power_preview_rev_1__1_;
            this.btn_power.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_power.FlatAppearance.BorderSize = 0;
            this.btn_power.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_power.Location = new System.Drawing.Point(1114, 12);
            this.btn_power.Name = "btn_power";
            this.btn_power.Size = new System.Drawing.Size(83, 59);
            this.btn_power.TabIndex = 0;
            this.btn_power.UseVisualStyleBackColor = false;
            this.btn_power.Click += new System.EventHandler(this.btn_power_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.flowLayoutPanel1.Controls.Add(this.btn_sale);
            this.flowLayoutPanel1.Controls.Add(this.btn_menu);
            this.flowLayoutPanel1.Controls.Add(this.btn_buy);
            this.flowLayoutPanel1.Controls.Add(this.btn_supplier);
            this.flowLayoutPanel1.Controls.Add(this.btn_client);
            this.flowLayoutPanel1.Controls.Add(this.btn_staff);
            this.flowLayoutPanel1.Controls.Add(this.btn_statistical);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 89);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(260, 746);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // btn_sale
            // 
            this.btn_sale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_sale.FlatAppearance.BorderSize = 0;
            this.btn_sale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sale.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_sale.Location = new System.Drawing.Point(3, 3);
            this.btn_sale.Margin = new System.Windows.Forms.Padding(3, 3, 0, 0);
            this.btn_sale.Name = "btn_sale";
            this.btn_sale.Size = new System.Drawing.Size(257, 80);
            this.btn_sale.TabIndex = 0;
            this.btn_sale.Text = "     Bán hàng";
            this.btn_sale.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sale.UseVisualStyleBackColor = false;
            this.btn_sale.Click += new System.EventHandler(this.btn_sale_Click);
            // 
            // btn_menu
            // 
            this.btn_menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_menu.FlatAppearance.BorderSize = 0;
            this.btn_menu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_menu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_menu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_menu.Location = new System.Drawing.Point(3, 86);
            this.btn_menu.Margin = new System.Windows.Forms.Padding(3, 3, 1, 0);
            this.btn_menu.Name = "btn_menu";
            this.btn_menu.Size = new System.Drawing.Size(257, 80);
            this.btn_menu.TabIndex = 1;
            this.btn_menu.Text = "     Menu";
            this.btn_menu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_menu.UseVisualStyleBackColor = false;
            this.btn_menu.Click += new System.EventHandler(this.btn_menu_Click);
            // 
            // btn_buy
            // 
            this.btn_buy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_buy.FlatAppearance.BorderSize = 0;
            this.btn_buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_buy.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buy.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_buy.Location = new System.Drawing.Point(3, 169);
            this.btn_buy.Margin = new System.Windows.Forms.Padding(3, 3, 1, 0);
            this.btn_buy.Name = "btn_buy";
            this.btn_buy.Size = new System.Drawing.Size(257, 80);
            this.btn_buy.TabIndex = 2;
            this.btn_buy.Text = "     Nhập hàng";
            this.btn_buy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_buy.UseVisualStyleBackColor = false;
            this.btn_buy.Click += new System.EventHandler(this.btn_buy_Click);
            // 
            // btn_supplier
            // 
            this.btn_supplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_supplier.FlatAppearance.BorderSize = 0;
            this.btn_supplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_supplier.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_supplier.Location = new System.Drawing.Point(3, 252);
            this.btn_supplier.Margin = new System.Windows.Forms.Padding(3, 3, 1, 0);
            this.btn_supplier.Name = "btn_supplier";
            this.btn_supplier.Size = new System.Drawing.Size(257, 80);
            this.btn_supplier.TabIndex = 4;
            this.btn_supplier.Text = "     Nhà cung cấp";
            this.btn_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_supplier.UseVisualStyleBackColor = false;
            this.btn_supplier.Click += new System.EventHandler(this.btn_supplier_Click);
            // 
            // btn_client
            // 
            this.btn_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_client.FlatAppearance.BorderSize = 0;
            this.btn_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_client.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_client.Location = new System.Drawing.Point(3, 335);
            this.btn_client.Margin = new System.Windows.Forms.Padding(3, 3, 1, 0);
            this.btn_client.Name = "btn_client";
            this.btn_client.Size = new System.Drawing.Size(257, 80);
            this.btn_client.TabIndex = 5;
            this.btn_client.Text = "     Khách Hàng";
            this.btn_client.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_client.UseVisualStyleBackColor = false;
            this.btn_client.Click += new System.EventHandler(this.btn_client_Click);
            // 
            // btn_staff
            // 
            this.btn_staff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_staff.FlatAppearance.BorderSize = 0;
            this.btn_staff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_staff.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_staff.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_staff.Location = new System.Drawing.Point(3, 418);
            this.btn_staff.Margin = new System.Windows.Forms.Padding(3, 3, 1, 0);
            this.btn_staff.Name = "btn_staff";
            this.btn_staff.Size = new System.Drawing.Size(257, 80);
            this.btn_staff.TabIndex = 6;
            this.btn_staff.Text = "     Nhân viên";
            this.btn_staff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_staff.UseVisualStyleBackColor = false;
            this.btn_staff.Click += new System.EventHandler(this.btn_staff_Click);
            // 
            // btn_statistical
            // 
            this.btn_statistical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(166)))), ((int)(((byte)(123)))));
            this.btn_statistical.FlatAppearance.BorderSize = 0;
            this.btn_statistical.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_statistical.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_statistical.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_statistical.Location = new System.Drawing.Point(3, 501);
            this.btn_statistical.Margin = new System.Windows.Forms.Padding(3, 3, 1, 0);
            this.btn_statistical.Name = "btn_statistical";
            this.btn_statistical.Size = new System.Drawing.Size(257, 80);
            this.btn_statistical.TabIndex = 7;
            this.btn_statistical.Text = "     Thống kê";
            this.btn_statistical.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_statistical.UseVisualStyleBackColor = false;
            this.btn_statistical.Click += new System.EventHandler(this.btn_statistical_Click);
            // 
            // pn_body
            // 
            this.pn_body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pn_body.Location = new System.Drawing.Point(260, 89);
            this.pn_body.Name = "pn_body";
            this.pn_body.Size = new System.Drawing.Size(1002, 746);
            this.pn_body.TabIndex = 2;
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(226)))), ((int)(((byte)(207)))));
            this.ClientSize = new System.Drawing.Size(1262, 835);
            this.Controls.Add(this.pn_body);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Name = "fMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fMain";
            this.Load += new System.EventHandler(this.fMain_Load);
            this.panel1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel pn_body;
        private System.Windows.Forms.Button btn_sale;
        private System.Windows.Forms.Button btn_menu;
        private System.Windows.Forms.Button btn_buy;
        private System.Windows.Forms.Button btn_power;
        private System.Windows.Forms.Button btn_supplier;
        private System.Windows.Forms.Button btn_client;
        private System.Windows.Forms.Button btn_staff;
        private System.Windows.Forms.Button btn_statistical;
    }
}