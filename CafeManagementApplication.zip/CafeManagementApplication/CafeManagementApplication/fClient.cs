﻿using CafeManagementApplication.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementApplication
{
    public partial class fClient : Form
    {
        public fClient()
        {
            InitializeComponent();
        }
        private void load()
        {
            string query = "select MaKH N'Mã khách hàng', TenKH N'Tên khách hàng',SDT N'Số điện thoại', DiaChi N'Địa chỉ',DiemTichLuy N'Điểm tích lũy' from KHACHHANG";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_kh.DataSource = result;
        }

        private void fClient_Load(object sender, EventArgs e)
        {
            load();
        }

        

        private void btn_search_Click(object sender, EventArgs e)
        {
            string query = "select MaKH N'Mã khách hàng', TenKH N'Tên khách hàng',SDT N'Số điện thoại', DiaChi N'Địa chỉ',DiemTichLuy N'Điểm tích lũy' from KHACHHANG where Tenkh like N'%" + txt_search.Text + "%' or SDT like '%"+ txt_search.Text + "%'";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_kh.DataSource = result;
        }
       
        int indexRow;

        private void dtgv_kh_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;

            if (indexRow >= 0)
            {

                DataGridViewRow row = dtgv_kh.Rows[indexRow];
                txt_id.Text = row.Cells[0].Value.ToString();
                txt_name.Text = row.Cells[1].Value.ToString();
                txt_phone.Text = row.Cells[2].Value.ToString();
                txt_address.Text = row.Cells[3].Value.ToString();
                txt_point.Text = row.Cells[4].Value.ToString();
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string test = txt_name.Text.Trim();
            string test1 = txt_phone.Text.Trim();


            if (test != "" && test1 != "")
            {
                string query = "declare @ref char(1) exec spAddkh N'" + txt_name.Text + "','" + txt_phone.Text + "',N'" + txt_address.Text + "','" + txt_point.Text + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("SĐT không đúng hoặc đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else

                    {
                        MessageBox.Show("Thêm thành công");
                    }
                    break;

                }
                load();
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            string test = txt_name.Text.Trim();
            string test1 = txt_phone.Text.Trim();
            string test2 = txt_id.Text.Trim();



            if (test != "" && test1 != "" && test2 != "")
            {
                string query = "declare @ref char(1) exec spUdkh '" + txt_id.Text + "', N'" + txt_name.Text + "','" + txt_phone.Text + "',N'" + txt_address.Text + "','" + txt_point.Text + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("SĐT không đúng hoặc đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else if (r == "2")
                    {
                        MessageBox.Show("Không được thay đổi đối tượng này");
                    }
                    else

                    {
                        MessageBox.Show("Cập nhật thành công");
                    }
                    break;

                }
                load();
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (indexRow >= 0)
            {
                string query = "declare @ref char(1) exec spDeleteKH '" + txt_id.Text + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("Không được xóa");
                    }
                    
                    break;

                }
                load();
            }
            else
            {
                MessageBox.Show("phải chọn 1 ô");
            }
        }
    }
}
