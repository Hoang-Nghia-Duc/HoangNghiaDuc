﻿namespace CafeManagementApplication
{
    partial class fMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_searchClient = new System.Windows.Forms.Button();
            this.nud_price = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_nameProduct = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.dtgv_recipe = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_search2 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_search2 = new System.Windows.Forms.TextBox();
            this.ds_dvt = new System.Windows.Forms.ComboBox();
            this.ds_nl = new System.Windows.Forms.ComboBox();
            this.btn_remove2 = new System.Windows.Forms.Button();
            this.btn_update2 = new System.Windows.Forms.Button();
            this.btn_add2 = new System.Windows.Forms.Button();
            this.nud_norms = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_id2 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtgv_product = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_remove3 = new System.Windows.Forms.Button();
            this.ds_nl2 = new System.Windows.Forms.ComboBox();
            this.btn_update3 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_add3 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_id3 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dtgv_nl = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_price)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_recipe)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_norms)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_product)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_nl)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txt_id);
            this.panel2.Controls.Add(this.btn_remove);
            this.panel2.Controls.Add(this.btn_update);
            this.panel2.Controls.Add(this.btn_add);
            this.panel2.Controls.Add(this.btn_searchClient);
            this.panel2.Controls.Add(this.nud_price);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txt_nameProduct);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txt_search);
            this.panel2.Location = new System.Drawing.Point(13, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(596, 316);
            this.panel2.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(113, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 24);
            this.label7.TabIndex = 19;
            this.label7.Text = "ID";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(221, 143);
            this.txt_id.Name = "txt_id";
            this.txt_id.ReadOnly = true;
            this.txt_id.Size = new System.Drawing.Size(225, 22);
            this.txt_id.TabIndex = 18;
            // 
            // btn_remove
            // 
            this.btn_remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_remove.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_remove.Location = new System.Drawing.Point(406, 262);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(86, 49);
            this.btn_remove.TabIndex = 17;
            this.btn_remove.Text = "Xóa";
            this.btn_remove.UseVisualStyleBackColor = false;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_update.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_update.Location = new System.Drawing.Point(314, 262);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(86, 49);
            this.btn_update.TabIndex = 16;
            this.btn_update.Text = "Sửa";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_add.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_add.Location = new System.Drawing.Point(222, 262);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(86, 49);
            this.btn_add.TabIndex = 15;
            this.btn_add.Text = "Thêm";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_searchClient
            // 
            this.btn_searchClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_searchClient.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_searchClient.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_searchClient.Location = new System.Drawing.Point(474, 45);
            this.btn_searchClient.Name = "btn_searchClient";
            this.btn_searchClient.Size = new System.Drawing.Size(86, 34);
            this.btn_searchClient.TabIndex = 14;
            this.btn_searchClient.Text = "Tìm";
            this.btn_searchClient.UseVisualStyleBackColor = false;
            this.btn_searchClient.Click += new System.EventHandler(this.btn_searchClient_Click_1);
            // 
            // nud_price
            // 
            this.nud_price.Location = new System.Drawing.Point(221, 217);
            this.nud_price.Maximum = new decimal(new int[] {
            -1530494977,
            232830,
            0,
            0});
            this.nud_price.Name = "nud_price";
            this.nud_price.Size = new System.Drawing.Size(225, 22);
            this.nud_price.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(113, 213);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "Đơn giá";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_nameProduct
            // 
            this.txt_nameProduct.Location = new System.Drawing.Point(221, 182);
            this.txt_nameProduct.Name = "txt_nameProduct";
            this.txt_nameProduct.Size = new System.Drawing.Size(225, 22);
            this.txt_nameProduct.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(113, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tên món";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(113, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tìm món";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(221, 52);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(225, 22);
            this.txt_search.TabIndex = 0;
            // 
            // dtgv_recipe
            // 
            this.dtgv_recipe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgv_recipe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgv_recipe.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgv_recipe.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(226)))), ((int)(((byte)(207)))));
            this.dtgv_recipe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_recipe.Location = new System.Drawing.Point(0, 0);
            this.dtgv_recipe.Name = "dtgv_recipe";
            this.dtgv_recipe.ReadOnly = true;
            this.dtgv_recipe.RowHeadersWidth = 51;
            this.dtgv_recipe.RowTemplate.Height = 24;
            this.dtgv_recipe.Size = new System.Drawing.Size(609, 316);
            this.dtgv_recipe.TabIndex = 0;
            this.dtgv_recipe.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_recipe_CellClick);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel4.Controls.Add(this.btn_search2);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txt_search2);
            this.panel4.Controls.Add(this.ds_dvt);
            this.panel4.Controls.Add(this.ds_nl);
            this.panel4.Controls.Add(this.btn_remove2);
            this.panel4.Controls.Add(this.btn_update2);
            this.panel4.Controls.Add(this.btn_add2);
            this.panel4.Controls.Add(this.nud_norms);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.txt_id2);
            this.panel4.Location = new System.Drawing.Point(13, 546);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(596, 315);
            this.panel4.TabIndex = 18;
            // 
            // btn_search2
            // 
            this.btn_search2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_search2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_search2.Location = new System.Drawing.Point(474, 16);
            this.btn_search2.Name = "btn_search2";
            this.btn_search2.Size = new System.Drawing.Size(86, 34);
            this.btn_search2.TabIndex = 22;
            this.btn_search2.Text = "Tìm";
            this.btn_search2.UseVisualStyleBackColor = false;
            this.btn_search2.Click += new System.EventHandler(this.btn_search2_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(94, 196);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 24);
            this.label8.TabIndex = 20;
            this.label8.Text = "Đơn vị";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(31, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(161, 24);
            this.label9.TabIndex = 21;
            this.label9.Text = "Tìm nguyên liệu";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_search2
            // 
            this.txt_search2.Location = new System.Drawing.Point(221, 18);
            this.txt_search2.Name = "txt_search2";
            this.txt_search2.Size = new System.Drawing.Size(225, 22);
            this.txt_search2.TabIndex = 20;
            this.txt_search2.TextChanged += new System.EventHandler(this.txt_search2_TextChanged);
            // 
            // ds_dvt
            // 
            this.ds_dvt.FormattingEnabled = true;
            this.ds_dvt.Items.AddRange(new object[] {
            "Gram",
            "Ml",
            "cái"});
            this.ds_dvt.Location = new System.Drawing.Point(222, 196);
            this.ds_dvt.Name = "ds_dvt";
            this.ds_dvt.Size = new System.Drawing.Size(224, 24);
            this.ds_dvt.TabIndex = 19;
            // 
            // ds_nl
            // 
            this.ds_nl.FormattingEnabled = true;
            this.ds_nl.Location = new System.Drawing.Point(222, 114);
            this.ds_nl.Name = "ds_nl";
            this.ds_nl.Size = new System.Drawing.Size(224, 24);
            this.ds_nl.TabIndex = 18;
            // 
            // btn_remove2
            // 
            this.btn_remove2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_remove2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_remove2.Location = new System.Drawing.Point(405, 236);
            this.btn_remove2.Name = "btn_remove2";
            this.btn_remove2.Size = new System.Drawing.Size(86, 49);
            this.btn_remove2.TabIndex = 17;
            this.btn_remove2.Text = "Xóa";
            this.btn_remove2.UseVisualStyleBackColor = false;
            this.btn_remove2.Click += new System.EventHandler(this.btn_remove2_Click);
            // 
            // btn_update2
            // 
            this.btn_update2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_update2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_update2.Location = new System.Drawing.Point(313, 236);
            this.btn_update2.Name = "btn_update2";
            this.btn_update2.Size = new System.Drawing.Size(86, 49);
            this.btn_update2.TabIndex = 16;
            this.btn_update2.Text = "Sửa";
            this.btn_update2.UseVisualStyleBackColor = false;
            this.btn_update2.Click += new System.EventHandler(this.btn_update2_Click);
            // 
            // btn_add2
            // 
            this.btn_add2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_add2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_add2.Location = new System.Drawing.Point(221, 236);
            this.btn_add2.Name = "btn_add2";
            this.btn_add2.Size = new System.Drawing.Size(86, 49);
            this.btn_add2.TabIndex = 15;
            this.btn_add2.Text = "Thêm";
            this.btn_add2.UseVisualStyleBackColor = false;
            this.btn_add2.Click += new System.EventHandler(this.btn_add2_Click);
            // 
            // nud_norms
            // 
            this.nud_norms.Location = new System.Drawing.Point(221, 157);
            this.nud_norms.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.nud_norms.Name = "nud_norms";
            this.nud_norms.Size = new System.Drawing.Size(225, 22);
            this.nud_norms.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(94, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 24);
            this.label4.TabIndex = 6;
            this.label4.Text = "Số lượng";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(94, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Nguyên liệu";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(94, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 24);
            this.label6.TabIndex = 3;
            this.label6.Text = "Mã món";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_id2
            // 
            this.txt_id2.Location = new System.Drawing.Point(221, 69);
            this.txt_id2.Name = "txt_id2";
            this.txt_id2.ReadOnly = true;
            this.txt_id2.Size = new System.Drawing.Size(225, 22);
            this.txt_id2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dtgv_recipe);
            this.panel3.Location = new System.Drawing.Point(615, 546);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(609, 318);
            this.panel3.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.dtgv_product);
            this.panel1.Location = new System.Drawing.Point(615, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(609, 316);
            this.panel1.TabIndex = 1;
            // 
            // dtgv_product
            // 
            this.dtgv_product.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgv_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgv_product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgv_product.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(226)))), ((int)(((byte)(207)))));
            this.dtgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_product.Location = new System.Drawing.Point(0, -1);
            this.dtgv_product.Name = "dtgv_product";
            this.dtgv_product.ReadOnly = true;
            this.dtgv_product.RowHeadersWidth = 51;
            this.dtgv_product.RowTemplate.Height = 24;
            this.dtgv_product.Size = new System.Drawing.Size(609, 317);
            this.dtgv_product.TabIndex = 0;
            this.dtgv_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_product_CellClick);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel5.Controls.Add(this.btn_remove3);
            this.panel5.Controls.Add(this.ds_nl2);
            this.panel5.Controls.Add(this.btn_update3);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.btn_add3);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.txt_id3);
            this.panel5.Location = new System.Drawing.Point(13, 335);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(596, 205);
            this.panel5.TabIndex = 19;
            // 
            // btn_remove3
            // 
            this.btn_remove3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_remove3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_remove3.Location = new System.Drawing.Point(405, 135);
            this.btn_remove3.Name = "btn_remove3";
            this.btn_remove3.Size = new System.Drawing.Size(86, 49);
            this.btn_remove3.TabIndex = 25;
            this.btn_remove3.Text = "Xóa";
            this.btn_remove3.UseVisualStyleBackColor = false;
            this.btn_remove3.Click += new System.EventHandler(this.btn_remove3_Click);
            // 
            // ds_nl2
            // 
            this.ds_nl2.FormattingEnabled = true;
            this.ds_nl2.Location = new System.Drawing.Point(222, 67);
            this.ds_nl2.Name = "ds_nl2";
            this.ds_nl2.Size = new System.Drawing.Size(224, 24);
            this.ds_nl2.TabIndex = 22;
            // 
            // btn_update3
            // 
            this.btn_update3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_update3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_update3.Location = new System.Drawing.Point(313, 135);
            this.btn_update3.Name = "btn_update3";
            this.btn_update3.Size = new System.Drawing.Size(86, 49);
            this.btn_update3.TabIndex = 24;
            this.btn_update3.Text = "Sửa";
            this.btn_update3.UseVisualStyleBackColor = false;
            this.btn_update3.Click += new System.EventHandler(this.btn_update3_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(94, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 24);
            this.label10.TabIndex = 21;
            this.label10.Text = "Nguyên liệu";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btn_add3
            // 
            this.btn_add3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(109)))), ((int)(((byte)(81)))));
            this.btn_add3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_add3.Location = new System.Drawing.Point(221, 135);
            this.btn_add3.Name = "btn_add3";
            this.btn_add3.Size = new System.Drawing.Size(86, 49);
            this.btn_add3.TabIndex = 23;
            this.btn_add3.Text = "Thêm";
            this.btn_add3.UseVisualStyleBackColor = false;
            this.btn_add3.Click += new System.EventHandler(this.btn_add3_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(94, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 24);
            this.label11.TabIndex = 20;
            this.label11.Text = "Mã món";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_id3
            // 
            this.txt_id3.Location = new System.Drawing.Point(221, 22);
            this.txt_id3.Name = "txt_id3";
            this.txt_id3.ReadOnly = true;
            this.txt_id3.Size = new System.Drawing.Size(225, 22);
            this.txt_id3.TabIndex = 19;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.dtgv_nl);
            this.panel6.Location = new System.Drawing.Point(614, 335);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(610, 205);
            this.panel6.TabIndex = 20;
            // 
            // dtgv_nl
            // 
            this.dtgv_nl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgv_nl.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgv_nl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgv_nl.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(226)))), ((int)(((byte)(207)))));
            this.dtgv_nl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_nl.Location = new System.Drawing.Point(0, 0);
            this.dtgv_nl.Name = "dtgv_nl";
            this.dtgv_nl.ReadOnly = true;
            this.dtgv_nl.RowHeadersWidth = 51;
            this.dtgv_nl.RowTemplate.Height = 24;
            this.dtgv_nl.Size = new System.Drawing.Size(610, 205);
            this.dtgv_nl.TabIndex = 0;
            // 
            // fMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(226)))), ((int)(((byte)(207)))));
            this.ClientSize = new System.Drawing.Size(1239, 876);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Name = "fMenu";
            this.Text = "fMenu";
            this.Load += new System.EventHandler(this.fMenu_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_price)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_recipe)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_norms)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_product)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_nl)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.NumericUpDown nud_price;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_nameProduct;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_searchClient;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.DataGridView dtgv_recipe;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_remove2;
        private System.Windows.Forms.Button btn_update2;
        private System.Windows.Forms.Button btn_add2;
        private System.Windows.Forms.NumericUpDown nud_norms;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_id2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dtgv_product;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox ds_dvt;
        private System.Windows.Forms.ComboBox ds_nl;
        private System.Windows.Forms.Button btn_search2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_search2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView dtgv_nl;
        private System.Windows.Forms.ComboBox ds_nl2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_id3;
        private System.Windows.Forms.Button btn_remove3;
        private System.Windows.Forms.Button btn_update3;
        private System.Windows.Forms.Button btn_add3;
    }
}