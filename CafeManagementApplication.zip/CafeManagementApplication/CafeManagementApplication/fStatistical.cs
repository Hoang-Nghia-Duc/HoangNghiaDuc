﻿using CafeManagementApplication.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementApplication
{
    public partial class fStatistical : Form
    {
        public fStatistical()
        {
            InitializeComponent();
        }
        private void loadhdb () 
        {
            string query = "select * from HOADONBAN where Ngayban >= convert(date,'"+date_from.Value.ToShortDateString()+"',103) and Ngayban <= convert(date,'"+ date_to.Value.ToShortDateString() + "',103)";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_hdb.DataSource = result;
        }

        private void loadhdn()
        {
            string query = "select * from HOADONNHAP where Ngaynhap >= convert(date,'" + date_from.Value.ToShortDateString() + "',103) and Ngaynhap <= convert(date,'" + date_to.Value.ToShortDateString() + "',103)";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_hdn.DataSource = result;
        }
        private void btn_TK_Click(object sender, EventArgs e)
        {
            loadhdb();
            loadhdn();
        }

        
        private void load_hdbct (string id)
        {
            
            string query = "SELECT * FROM HOADONBAN_CHITIET WHERE MaHD='" + id + "'";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_hdbct.DataSource = null;
            dtgv_hdbct.DataSource = result;
        }
        int indexRowb;
        private void dtgv_hdb_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRowb = e.RowIndex;
            if (indexRowb >= 0)
            {
                DataGridViewRow row = dtgv_hdb.Rows[indexRowb];
                load_hdbct(row.Cells[0].Value.ToString() );

            }
        }
        int indexRowN;

        private void dtgv_hdn_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRowN = e.RowIndex;
            if (indexRowN >= 0)
            {

                DataGridViewRow row = dtgv_hdn.Rows[indexRowN];


                string query = "SELECT * FROM HOADONNHAP_CHITIET WHERE MaHD='" + row.Cells[0].Value.ToString() + "'";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                dtgv_hdnct.DataSource = result;

            }
        }

    }
}
