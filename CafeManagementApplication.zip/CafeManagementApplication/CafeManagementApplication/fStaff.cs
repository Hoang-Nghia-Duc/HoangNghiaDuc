﻿using CafeManagementApplication.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementApplication
{
    public partial class fStaff : Form
    {
        public fStaff()
        {
            InitializeComponent();
        }
        private void fStaff_Load(object sender, EventArgs e)
        {
            load();
        }
        private void load()
        {
            string query = "select manv N'Mã nhân viên', tennv N'Tên nhân viên' , sdt N'Số điện thoại',ngaysinh N'Ngày sinh' from nhanvien";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_staff.DataSource = result;
        }

        int indexRow;

        private void dtgv_staff_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;

            if (indexRow >= 0)
            {

                DataGridViewRow row = dtgv_staff.Rows[indexRow];
                txt_id.Text = row.Cells[0].Value.ToString();
                txt_name.Text = row.Cells[1].Value.ToString();
                txt_phone.Text = row.Cells[2].Value.ToString();
                txt_date.Text = row.Cells[3].Value.ToString();
                
            }
        }
        private void btn_search_Click(object sender, EventArgs e)
        {
            string query = "select manv N'Mã nhân viên', tennv N'Tên nhân viên' , sdt N'Số điện thoại',ngaysinh N'Ngày sinh' from nhanvien where tennv like N'%" + txt_search.Text + "%' or SDT like '%" + txt_search.Text + "%'";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_staff.DataSource = result;
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            string test = txt_name.Text.Trim();
            string test1 = txt_phone.Text.Trim();


            if (test != "" && test1 != "")
            {
                string date= txt_date.Value.ToShortDateString();
                string query = "declare @ref char(1) exec spAddnv N'" + txt_name.Text + "','" + txt_phone.Text + "',N'" + date + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("SĐT không đúng hoặc đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else

                    {
                        MessageBox.Show("Thêm thành công");
                    }
                    break;

                }
                load();
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            string test = txt_name.Text.Trim();
            string test1 = txt_phone.Text.Trim();
            string test2 = txt_id.Text.Trim();



            if (test != "" && test1 != "" && test2 != "")
            {
                string date = txt_date.Value.ToShortDateString();
                string query = "declare @ref char(1) exec spUdnv '" + txt_id.Text + "', N'" + txt_name.Text + "','" + txt_phone.Text + "',N'" + date + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("SĐT không đúng hoặc đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else if (r == "2")
                    {
                        MessageBox.Show("Không được thay đổi đối tượng này");
                    }
                    else

                    {
                        MessageBox.Show("Cập nhật thành công");
                    }
                    break;

                }
                load();
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (indexRow >= 0)
            {
                string query = "EXEC spDeleteNV '" + txt_id.Text+"'";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                
                load();
            }
            else
            {
                MessageBox.Show("phải chọn 1 ô");
            }
        }
    }
}
