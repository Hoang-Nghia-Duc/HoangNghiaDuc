﻿using CafeManagementApplication.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CafeManagementApplication
{
    public partial class fBill : Form
    {
        public fBill()
        {
            InitializeComponent();
        }
        double sumMoney;
        double pay;
        

        private void fBill_Load(object sender, EventArgs e)
        {
            // hóa đơn chi tiết
            lv_product.Columns[0].Width = (int)(lv_product.Width *0.25);
            lv_product.Columns[1].Width = (int)(lv_product.Width *0.25);
            lv_product.Columns[2].Width = (int)(lv_product.Width *0.25);
            lv_product.Columns[3].Width = (int)(lv_product.Width *0.25);

            lv_product.View = View.Details;
            lv_product.GridLines = true;
            lv_product.FullRowSelect = true;

            // hóa đơn
            
            lv_bill.Columns[0].Width = (int)(lv_product.Width * 0.25);
            lv_bill.Columns[1].Width = (int)(lv_product.Width * 0.25);
            lv_bill.Columns[2].Width = (int)(lv_product.Width * 0.25);
            lv_bill.Columns[3].Width = (int)(lv_product.Width * 0.25);

            lv_bill.View = View.Details;
            lv_bill.GridLines = true;
            lv_bill.FullRowSelect = true;
            //box
            string query = "select * from SANPHAM";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_sp.DataSource = table;
            ds_sp.DisplayMember = "TenSP";
            ds_sp.ValueMember = "Dongia";

            // view ds sản phẩm

            

            // mặc địch khách hàng
            string search = txt_phone.Text;
            query = "select * from KHACHHANG where SDT ='0'";
            DataTable tableKH = DataProvider.Instance.ExecuteQuery(query);
            ds_kh.DataSource = tableKH;
            ds_kh.DisplayMember = "TenKH";
            ds_kh.ValueMember = "SDT";






        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (ds_sp.Text == "")
            {
                MessageBox.Show("Phải chọn  1 sản phẩm");
                return;
            }

            int sum;
            foreach (ListViewItem i in lv_product.Items)
            {
                if (i.SubItems[0].Text== ds_sp.Text)
                {
                    int count = Convert.ToInt32(i.SubItems[2].Text);
                    count += Convert.ToInt32(nud_number.Text);
                    i.SubItems[2].Text = count.ToString();
                    sum = count * Convert.ToInt32(i.SubItems[1].Text);
                    i.SubItems[3].Text = sum.ToString();

                    loadBill();
                    return;
                }
            }
            sum= Convert.ToInt32((ds_sp.SelectedValue.ToString()))*Convert.ToInt32(nud_number.Text);
            ListViewItem item =lv_product.Items.Add(ds_sp.Text);
            item.SubItems.Add(ds_sp.SelectedValue.ToString());
            item.SubItems.Add(nud_number.Text);
            item.SubItems.Add(sum.ToString());
            loadBill();



        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (lv_product.SelectedItems.Count > 0)
            {
                lv_product.SelectedItems[0].SubItems[0].Text =(ds_sp.Text);
                lv_product.SelectedItems[0].SubItems[1].Text = ds_sp.SelectedValue.ToString();
                lv_product.SelectedItems[0].SubItems[2].Text = nud_number.Text;
                int sum = Convert.ToInt32(nud_number.Text) * Convert.ToInt32(ds_sp.SelectedValue.ToString());
                lv_product.SelectedItems[0].SubItems[3].Text =sum.ToString();


            }
            else
            {
                MessageBox.Show("Phải chọn  1 dòng");
            }
            loadBill();

        }

        private void lv_product_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lv_product.SelectedItems.Count>0)
            {
                ds_sp.Text = lv_product.SelectedItems[0].SubItems[0].Text;
                nud_number.Text = lv_product.SelectedItems[0].SubItems[2].Text; 
            }
            


        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (lv_product.SelectedItems.Count > 0)
            {
                lv_product.Items.Remove(lv_product.SelectedItems[0]); 
            }
            else
            {
                MessageBox.Show("Phải chọn  1 dòng");
            }
            loadBill();

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string search = txt_search.Text;
            string query = "select * from SANPHAM where TenSP like N'%"+search+"%'";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_sp.DataSource = table;
            ds_sp.DisplayMember = "TenSP";
            ds_sp.ValueMember = "Dongia";
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            reset();

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_searchClient_Click(object sender, EventArgs e)
        {
            string search = txt_phone.Text;
            string query = "select * from KHACHHANG where SDT like '%" + search + "%'";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_kh.DataSource = table;
            ds_kh.DisplayMember = "TenKH";
            ds_kh.ValueMember = "SDT";

        }

        

        private void loadBill()
        {
            sumMoney = 0.0;
            pay = 0.0;
            foreach (ListViewItem item in lv_product.Items)
            {
                sumMoney += Convert.ToInt32(item.SubItems[3].Text);

            }
            double giamgia = (Convert.ToInt32(nud_discount.Text));

            pay = sumMoney - sumMoney * (giamgia / 100);
            lv_bill.Items.Clear();
            if (ds_kh.Text == null)
            {
                ListViewItem bill = lv_bill.Items.Add("Không có");
                bill.SubItems.Add(sumMoney.ToString());
                bill.SubItems.Add(nud_discount.Text);
                bill.SubItems.Add(pay.ToString());
            }
            else
            {
                ListViewItem bill = lv_bill.Items.Add(ds_kh.Text);
                bill.SubItems.Add(sumMoney.ToString());
                bill.SubItems.Add(nud_discount.Text);
                bill.SubItems.Add(pay.ToString());
            }
        }

        

        private void ds_kh_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadBill();
        }

        

        private void nud_discount_ValueChanged(object sender, EventArgs e)
        {
            
            loadBill();
        }

        private void btn_bill_Click(object sender, EventArgs e)
        {
            /*
            //hóa đơn
            string chietkhau = nud_discount.Text;
            string sdt= ds_kh.SelectedValue.ToString();
            

            
            
            string query = "exec sp_addBill "+chietkhau+",'"+sdt+"'";
            DataProvider.Instance.ExecuteQuery(query);
            //Hóa đơn chi tiết
            string tenSP, Soluong;
            foreach (ListViewItem item in lv_product.Items)
            {
                tenSP = item.SubItems[0].Text;
                Soluong = item.SubItems[2].Text;

                query = "exec sp_addBill_info N'"+ tenSP + "',"+ Soluong;
                DataProvider.Instance.ExecuteQuery(query);
            }
            reset();
            MessageBox.Show("Tạo hóa đơn thành công");
            */
            try
            {
                string chietkhau = nud_discount.Text;
                string sdt = ds_kh.SelectedValue.ToString();




                string query = "exec sp_addBill " + chietkhau + ",'" + sdt + "'";
                DataProvider.Instance.ExecuteQuery(query);
                //Hóa đơn chi tiết
                string tenSP, Soluong;
                foreach (ListViewItem item in lv_product.Items)
                {
                    tenSP = item.SubItems[0].Text;
                    Soluong = item.SubItems[2].Text;

                    query = "exec sp_addBill_info N'" + tenSP + "'," + Soluong;
                    DataProvider.Instance.ExecuteQuery(query);
                }
                reset();
                MessageBox.Show("Tạo hóa đơn thành công");
            }
            catch (SqlException ex)
            {
                reset();
                MessageBox.Show("Có lỗi");
            }

        }
        private void reset()
        {
            lv_product.Items.Clear();
            lv_bill.Items.Clear();
            txt_phone.Text = string.Empty;
            ds_kh.Text = string.Empty;
            txt_search.Text = string.Empty;
            ds_sp.Text = string.Empty;
            nud_number.Text = "0";
            nud_discount.Text= "0";
            loadBill();
        }
        private void dtgv_product_SelectionChanged(object sender, EventArgs e)
        {

        }

        private void btn_addkh_Click(object sender, EventArgs e)
        {
            fClient f = new fClient();
            f.Show();
            f.Size = new Size(1280, 720);
        }
    }
}
