﻿using CafeManagementApplication.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CafeManagementApplication
{
    public partial class fMenu : Form
    {
        public fMenu()
        {
            InitializeComponent();
        }
        private void page_load()
        {
            dtgv_product.ColumnHeadersDefaultCellStyle.Font = new Font("arial", 12, FontStyle.Bold);



            string query = "select masp as N'Mã sản phẩm',tensp as N'Tên sản phẩm',dongia as N'Đơn giá' from SANPHAM";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_product.DataSource = result;
            query = "select * from NguyenLieu";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_nl.DataSource = table;
            ds_nl.DisplayMember = "TenNL";
            ds_nl.ValueMember = "MaNL";

            // ng liệu
            loadNL("");

        }

        
        private void fMenu_Load(object sender, EventArgs e)
        {
            page_load();
        }
        private void load_recepe(string id)
        {
            string query = "select MaSP as N'Mã sản phẩm',TenNL as N'Tên nguyên liệu' , KhoiLuongSuDung as N'Khối lượng sử dụng', DonVi_NL as N'Đơn vị tính'  from CONGTHUCSP join NGUYENLIEU on CONGTHUCSP.MaNL=NGUYENLIEU.MaNL Where masp='" + id+"'";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_recipe.DataSource = null;
            dtgv_recipe.DataSource = result;
        }
        

        private void btn_searchClient_Click_1(object sender, EventArgs e)
        {
            string query = "select masp as N'Mã sản phẩm',tensp as N'Tên sản phẩm',dongia as N'Đơn giá' from SANPHAM where tensp like N'%" + txt_search.Text + "%'";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_product.DataSource = result;
        }

        int indexRowP;
        private void dtgv_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {   
            
            indexRowP = e.RowIndex;

            if (indexRowP>=0)
            {
                
                DataGridViewRow row = dtgv_product.Rows[indexRowP];
                txt_id.Text = row.Cells[0].Value.ToString();
                txt_nameProduct.Text = row.Cells[1].Value.ToString();
                nud_price.Text = row.Cells[2].Value.ToString();
                txt_id2.Text = row.Cells[0].Value.ToString();

                load_recepe(row.Cells[0].Value.ToString());

                

            }
        }

        

        private void btn_search2_Click(object sender, EventArgs e)
        {
            string query = "select * from NguyenLieu where TenNL like N'%" + txt_search2.Text + "%'";
            DataTable table = DataProvider.Instance.ExecuteQuery(query);
            ds_nl.DataSource = table;
            ds_nl.DisplayMember = "TenNL";
            ds_nl.ValueMember = "MaNL";
            loadNL(txt_search2.Text);


        }
        int indexRowR;
        private void dtgv_recipe_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRowR = e.RowIndex;

            if (indexRowR >= 0)
            {

                DataGridViewRow row = dtgv_recipe.Rows[indexRowR];
                txt_id2.Text = row.Cells[0].Value.ToString();
                ds_nl.Text = row.Cells[1].Value.ToString();
                nud_norms.Text = row.Cells[2].Value.ToString();
                ds_dvt.Text = row.Cells[3].Value.ToString();
                



            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string test = txt_nameProduct.Text.Trim();

            if (test != "")
            {
                string query = "declare @ref char(1) exec spAddSP N'" + txt_nameProduct.Text + "', " + nud_price.Text + ", @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("Sản phẩm đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else

                    {
                        MessageBox.Show("Thêm thành công");
                    }
                    break;

                }
                page_load();
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }


        }

        private void btn_update_Click(object sender, EventArgs e)
        {
           
            if (indexRowP >= 0)
            {
                DataGridViewRow rowT = dtgv_product.Rows[indexRowP];
                int rowCount, rowindex;
                rowCount = dtgv_product.Rows.Count;
                rowindex = rowT.Index;
                if (rowindex < (rowCount-1))
                {
                    string query = "declare @ref char(1) exec spUdSP '" + txt_id.Text + "', N'" + txt_nameProduct.Text + "', " + nud_price.Text + ", @ref out select @ref";
                    DataTable result = DataProvider.Instance.ExecuteQuery(query);
                    foreach (DataRow row in result.Rows)
                    {
                        string r = row[0].ToString();
                        if (r == "1")
                        {
                            MessageBox.Show("Sản phẩm đã tồn tại");
                        }
                        else if (r == "0")
                        {
                            MessageBox.Show("Có lỗi");
                        }
                        else

                        {
                            MessageBox.Show("Sửa thành công");
                        }
                        break;

                    }
                    page_load();
                }
                else
                {
                    MessageBox.Show( "Lựa chọn không hợp lệ" );
                }
                
            }

        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (indexRowP >= 0)
            {
                string query = "delete from CONGTHUCSP where MaSP='" + txt_id.Text+"' delete from SANPHAM where MaSP='" + txt_id.Text+"'";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                page_load();
            }
            else
            {
                MessageBox.Show("phải chọn 1 ô");
            }
        }

        private void btn_add2_Click(object sender, EventArgs e)
        {
            string testID = txt_id2.Text.Trim();
            string testName = ds_nl.Text.Trim();
            string tesDVT = ds_dvt.Text.Trim();

            if (testID != "" & testName!= "" & tesDVT!= "")
            {
                string query = "declare @ref char(1) exec spaddCT '"+txt_id2.Text+"', N'"+ds_nl.Text+"', "+ nud_norms.Text + ",'"+ ds_dvt.Text + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("Sản phẩm đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else

                    {
                        MessageBox.Show("Thêm thành công");
                    }
                    break;

                }
                load_recepe(txt_id2.Text);
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }

        }

        private void btn_update2_Click(object sender, EventArgs e)
        {
            string testID = txt_id2.Text.Trim();
            string testName = ds_nl.Text.Trim();
            string tesDVT = ds_dvt.Text.Trim();

            if (testID != "" & testName != "" & tesDVT != "")
            {
                string query = "declare @ref char(1) exec spUdCT '" + txt_id2.Text + "', N'" + ds_nl.Text + "', " + nud_norms.Text + ",'" + ds_dvt.Text + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("Sản phẩm đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else

                    {
                        MessageBox.Show("Sửa thành công");
                    }
                    break;

                }
                load_recepe(txt_id2.Text);
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }
        }

        private void btn_remove2_Click(object sender, EventArgs e)
        {
            if (indexRowP >= 0)
            {
                string query = "delete from CONGTHUCSP where MaSP='" + txt_id2.Text + "' and MaNL='"+ds_nl.SelectedValue.ToString()+ "'";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                load_recepe(txt_id2.Text);
            }
            else
            {
                MessageBox.Show("phải chọn 1 ô");
            }
        }



        private void loadNL(string value)
        {
            string query = "select * from NguyenLieu where tennl like N'%"+value+"%'";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            dtgv_nl.DataSource = result;
            ds_nl2.DataSource = result;
            ds_nl2.DisplayMember = "TenNL";
            ds_nl2.ValueMember = "MaNL";
        }

        private void txt_search2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_add3_Click(object sender, EventArgs e)
        {
            string test = ds_nl2.Text.Trim();

            if (test != "")
            {
                string query = "declare @ref char(1) exec spaddNL N'" + ds_nl2.Text + "', @ref out select @ref";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                foreach (DataRow row in result.Rows)
                {
                    string r = row[0].ToString();
                    if (r == "1")
                    {
                        MessageBox.Show("Nguyên liệu đã tồn tại");
                    }
                    else if (r == "0")
                    {
                        MessageBox.Show("Có lỗi");
                    }
                    else

                    {
                        MessageBox.Show("Thêm thành công");
                    }
                    break;

                }
                page_load();
            }
            else
            {
                MessageBox.Show("Không được để trống");
            }
        }
        int indexRownl;

        private void btn_update3_Click(object sender, EventArgs e)
        {
            if (indexRownl >= 0)
            {
                DataGridViewRow rowT = dtgv_nl.Rows[indexRownl];
                int rowCount, rowindex;
                rowCount = dtgv_nl.Rows.Count;
                rowindex = rowT.Index;
                if (rowindex < (rowCount - 1))
                {
                    string query = "declare @ref char(1) exec spUdSP '" + txt_id3.Text + "', N'" + ds_nl2.Text + "', @ref out select @ref";
                    DataTable result = DataProvider.Instance.ExecuteQuery(query);
                    foreach (DataRow row in result.Rows)
                    {
                        string r = row[0].ToString();
                        if (r == "1")
                        {
                            MessageBox.Show("Sản phẩm đã tồn tại");
                        }
                        else if (r == "0")
                        {
                            MessageBox.Show("Có lỗi");
                        }
                        else

                        {
                            MessageBox.Show("Sửa thành công");
                        }
                        break;

                    }
                    page_load();
                }
                else
                {
                    MessageBox.Show("Lựa chọn không hợp lệ");
                }

            }
        }

        private void btn_remove3_Click(object sender, EventArgs e)
        {
            if (indexRowP >= 0)
            {
                string query = "exec spDeleteNL '"+txt_id3+"'";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                page_load();
            }
            else
            {
                MessageBox.Show("phải chọn 1 ô");
            }
        }
    }
}
